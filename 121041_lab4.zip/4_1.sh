clear
ch=1;
while [ $ch = 1 ]
do
echo "Enter number below 50: "
read n
if [ $n -lt 50 ]
	then echo square is `expr $n \* $n `
else
	echo "invalid. input > 50"
fi
echo "do u want to continue? 0/1 "
	read ch
	
if [ $ch = 0 ]
then exit 
fi

done 
