echo Enter the filename
read fname
w=`cat $fname | wc -w`
echo Number of words in $fname is $w

