clear
echo "enter a number: "
read n

a=` expr $n + 1 `
b=` expr $n \* $a ` 
echo `expr $b \/ 2 `;

