clear
echo "enter a number: "
read n
x=2
flag=0
cnd=` expr $n \/ 2 `
while [ $x \< $cnd ] 
do
mod=` expr $n % $x `

	if [ $mod = 0 ]
	then
		flag=1
	fi
	x=` expr $x + 1 `
done
if [ $flag = 1 ]
then echo "Not a prime" 
else
	echo "It is prime" 
fi


