echo Enter a filename
read fname
echo 'Do you want to revoke the read and write permissions for file $fname?'
echo 'If yes then type y'
read ch
if [ $ch = 'y' -o $ch = 'Y' ]
then 
	echo Write the code for permission
	read c
	chmod $c $fname
else
echo No changes needed
fi
