echo Enter the filename
read fname
w=`cat $fname | wc -w`
c=`cat $fname | wc -c`
l=`cat $fname | wc -l`
echo Number of characters in $fname is :$c
echo Number of words in $fname is :$w
echo Number of lines in $fname is :$l
