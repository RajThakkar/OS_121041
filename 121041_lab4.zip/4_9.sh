echo "enter your file name"
read fname
l=`wc -l $fname|cut -d " " -f 1`
echo $l
space=0
cnt=0
for (( i=1; i<=l; i++))
do
        n=1
        line=`head -$i $fname|tail -1`
        ch=`echo $line|cut -c $n`
        while [ "$ch" != "" ]
        do
                if [ "$ch" = " " ]
                then
                space=`expr $space + 1`
                else
                cnt=`expr $cnt + 1`
                fi
                n=`expr $n + 1`
                ch=`echo $line|cut -c $n`

        done
done
echo no. of space $space


