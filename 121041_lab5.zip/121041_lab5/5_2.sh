clear
echo "Enter a string: "
read str
re=` expr $str | rev `
if [ $str = $re ]
then echo "Its a palindrome"
else
	"Not a palindrome" 
fi
