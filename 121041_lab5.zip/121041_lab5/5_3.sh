clear
cnt=` expr $1 + 1`
while [ $cnt \> 1 ]
do
	echo "$2"
	cnt=` expr $cnt - 1 `
	
done
