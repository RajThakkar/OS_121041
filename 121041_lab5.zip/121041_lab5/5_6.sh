clear
a=` expr $1 + 1 `
b=` expr $a \* $1 `
c=` expr $b \/ 2 `
echo sum till the number is $c
