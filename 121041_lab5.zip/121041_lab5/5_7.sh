clear
echo "enter an alphabet: "
read a
ls $a*
