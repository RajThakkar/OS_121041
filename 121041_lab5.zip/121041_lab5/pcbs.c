// Single Producer Single Consumer using 
#include<stdio.h>

void main()
{
int ch;
int tail=0;
do
{
printf("\n\n1.Produce");
printf("\n2.Consume");
printf("\n0. Exit");
printf("\nEnter choice: ");
scanf("%d", &ch);

switch (ch)
{
	case 1: {
	if( tail == 3 )
	{ printf("\nSleep producer. buffer full");
		break;}
	else
	{
	tail++;
	printf("\nitem added");
	}
	break;
	}
	
	case 2: {
	if( tail == 0 )
	{
		printf("\nWait. Buffer empty");
		break;
		}
	else
	{
		tail--;
		printf("\nItem consumed");
		break;
	}
		}
}
}while(ch!=0);
}	 
