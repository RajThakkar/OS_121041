clear
echo $1 + $2 = `expr $1 + $2` 
echo $1 - $2 = `expr $1 - $2` 
echo multiplication =  `expr $1 \* $2` 
echo $1/$2 = `expr $1  \/ $2` 
echo $1 % $2 = `expr $1 \% $2` 
