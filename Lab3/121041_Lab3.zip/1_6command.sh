clear
echo "enter command: "
read string
echo `$string` 
