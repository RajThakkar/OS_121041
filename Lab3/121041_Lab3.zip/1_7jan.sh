clear
echo "enter text: "
read string

case $string in

Jan) echo January ;; 
Janu) echo "January" ;; 
Janua) echo "January" ;;

esac
