 #include "calcul.h"
void add_prog_1(char *host)
{
    CLIENT *clnt;
    int  *result_1;
    intpair  add_1_arg;
    int  *result_2;
    intpair  sub_1_arg;
    int  *result_3;
    intpair  mul_1_arg;
    int  *result_4;
    intpair  div_1_arg;

#ifndef    DEBUG
    clnt = clnt_create (host, ADD_PROG, ADD_VERS, "udp");
    if (clnt == NULL) {
        clnt_pcreateerror (host);
        exit (1);
    }

printf("\n enter 1st value for add,sub,mul,div: \n");
scanf("%d",&add_1_arg.a);
scanf("%d",&sub_1_arg.a);
scanf("%d",&mul_1_arg.a);
scanf("%d",&div_1_arg.a);
printf("\n enter 2nd value for add,sub,mul,div: \n");
scanf("%d",&add_1_arg.b);
scanf("%d",&sub_1_arg.b);
scanf("%d",&mul_1_arg.b);
scanf("%d",&div_1_arg.b);
#endif    /* DEBUG */

    result_1 = add_1(&add_1_arg, clnt);
    if (result_1 == (int *) NULL) {
        clnt_perror (clnt, "call failed");
    }
    result_2 = sub_1(&sub_1_arg, clnt);
    if (result_2 == (int *) NULL) {
        clnt_perror (clnt, "call failed");
    }
    result_3 = mul_1(&mul_1_arg, clnt);
    if (result_3 == (int *) NULL) {
        clnt_perror (clnt, "call failed");
    }
    result_4 = div_1(&div_1_arg, clnt);
    if (result_4 == (int *) NULL) {
        clnt_perror (clnt, "call failed");
    }
else
{
printf("\n result=%d\n",*result_1);
printf("\n result=%d\n",*result_2);
printf("\n result=%d\n",*result_3);
printf("\n result=%d\n",*result_4);
}
#ifndef    DEBUG
    clnt_destroy (clnt);
#endif     /* DEBUG */
}
int main (int argc, char *argv[])
{
    char *host;
    if (argc < 2) {
        printf ("usage: %s server_host\n", argv[0]);
        exit (1);
    }
    host = argv[1];
    add_prog_1 (host);
   exit (0);
}
