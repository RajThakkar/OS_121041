#include"calcul.h"
int * add_1_svc(intpair *argp, struct svc_req *rqstp)
{
    static int  result;
    result = argp->a + argp->b;
    printf("\nadd=\n");
    return &result;
}

int * sub_1_svc(intpair *argp, struct svc_req *rqstp)
{
    static int  result;
    result = argp->a - argp->b;
    printf("\nsub=\n");
    return &result;
}

int * mul_1_svc(intpair *argp, struct svc_req *rqstp)
{
    static int  result;
    result = argp->a * argp->b;
    printf("\nmul=\n");
    return &result;
}

int * div_1_svc(intpair *argp, struct svc_req *rqstp)
{
    static int  result;
    result = argp->a / argp->b;
    printf("\ndiv=\n");
    return &result;
}

