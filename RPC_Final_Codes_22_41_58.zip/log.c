#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>
int main(int argc, char *argv[])
{
     //   if (argc < 2) { printf("Usage: %s filename\n",argv[0]); exit(-1); }
	
        struct stat fst;
        bzero(&fst,sizeof(fst));
        
        time_t a;
        char str[50];
	char fname[]= "abc";
	int uid;
        if (stat(fname,&fst) != 0) { printf("stat() failed with errno %d\n",errno); exit(-1); }

        printf("Information for %s\n",argv[1]);
        printf("----------------------------\n\n");
        printf("Last accessed:\t %s",ctime(&fst.st_atime));
        printf("Last modified:\t %s",ctime(&fst.st_mtime));
        printf("Last changed:\t %s",ctime(&fst.st_ctime)); 
        
	a=ctime(&fst.st_mtime);
	//printf("\n%s", a);
	strftime(str, 50, "%Y-%m-%d_%H:%M:%S", localtime(&fst.st_mtime));
	//strftime(str, 20, "%Y-%m-%d_%H:%M:%S", localtime(&a));
	//strftime(str, 50, "%c", localtime(&a));
	printf("\nString: %s\n", str);
	
	if (stat(fname,&fst) != 0) { printf("stat() failed with errno %d\n",errno); exit(-1); }
	printf("Ownership:     UID=%ld   GID=%ld\n", (long) fst.st_uid, (long) fst.st_gid);
	uid=fst.st_uid;
	printf("\ninteger uid: %d", uid);
        
        return 0;
}
